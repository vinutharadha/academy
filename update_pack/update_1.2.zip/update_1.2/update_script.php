<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

  // creating currency table
  $fields = array(
    'id' => array(
            'type' => 'INT',
            'primary' => TRUE,
            'auto_increment' => TRUE,
            'constraint' => '11'
    ),
    'name' => array(
            'type' => 'VARCHAR',
            'null'  => TRUE,
						'constraint' => '255'
    ),
    'code' => array(
						'type' => 'VARCHAR',
						'null'  => TRUE,
						'constraint' => '255'
    ),
    'symbol' => array(
						'type' => 'VARCHAR',
						'null'  => TRUE,
						'constraint' => '255'
    ),
    'paypal_supported' => array(
            'type' => 'INT',
            'null' => TRUE,
            'constraint' => '11'
    ),
		'stripe_supported' => array(
            'type' => 'INT',
            'null' => TRUE,
            'constraint' => '11'
    ),
  );

	$CI->dbforge->add_key('id', TRUE); // defining id as primary key
	$CI->dbforge->add_field($fields);
	$CI->dbforge->create_table('currency'); // table has to be added after adding the columns


	// insert currencies inside currency table
	$sql = "
	INSERT INTO `currency` (`id`, `name`, `code`, `symbol`, `paypal_supported`, `stripe_supported`)
	VALUES
		(1,'Leke','ALL','Lek',0,1),
		(2,'Dollars','USD','$',1,1),
		(3,'Afghanis','AFN','؋',0,1),
		(4,'Pesos','ARS','$',0,1),
		(5,'Guilders','AWG','ƒ',0,1),
		(6,'Dollars','AUD','$',1,1),
		(7,'New Manats','AZN','ман',0,1),
		(8,'Dollars','BSD','$',0,1),
		(9,'Dollars','BBD','$',0,1),
		(10,'Rubles','BYR','p.',0,0),
		(11,'Euro','EUR','€',1,1),
		(12,'Dollars','BZD','BZ$',0,1),
		(13,'Dollars','BMD','$',0,1),
		(14,'Bolivianos','BOB','$"."b',0,1),
		(15,'Convertible Marka','BAM','KM',0,1),
		(16,'Pula','BWP','P',0,1),
		(17,'Leva','BGN','лв',0,1),
		(18,'Reais','BRL','R$',1,1),
		(19,'Pounds','GBP','£',1,1),
		(20,'Dollars','BND','$',0,1),
		(21,'Riels','KHR','៛',0,1),
		(22,'Dollars','CAD','$',1,1),
		(23,'Dollars','KYD','$',0,1),
		(24,'Pesos','CLP','$',0,1),
		(25,'Yuan Renminbi','CNY','¥',0,1),
		(26,'Pesos','COP','$',0,1),
		(27,'Colón','CRC','₡',0,1),
		(28,'Kuna','HRK','kn',0,1),
		(29,'Pesos','CUP','₱',0,0),
		(30,'Koruny','CZK','Kč',1,1),
		(31,'Kroner','DKK','kr',1,1),
		(32,'Pesos','DOP ','RD$',0,1),
		(33,'Dollars','XCD','$',0,1),
		(34,'Pounds','EGP','£',0,1),
		(35,'Colones','SVC','$',0,0),
		(36,'Pounds','FKP','£',0,1),
		(37,'Dollars','FJD','$',0,1),
		(38,'Cedis','GHC','¢',0,0),
		(39,'Pounds','GIP','£',0,1),
		(40,'Quetzales','GTQ','Q',0,1),
		(41,'Pounds','GGP','£',0,0),
		(42,'Dollars','GYD','$',0,1),
		(43,'Lempiras','HNL','L',0,1),
		(44,'Dollars','HKD','$',1,1),
		(45,'Forint','HUF','Ft',1,1),
		(46,'Kronur','ISK','kr',0,1),
		(47,'Rupees','INR','Rp',0,1),
		(48,'Rupiahs','IDR','Rp',0,1),
		(49,'Rials','IRR','﷼',0,0),
		(50,'Pounds','IMP','£',0,0),
		(51,'New Shekels','ILS','₪',1,1),
		(52,'Dollars','JMD','J$',0,1),
		(53,'Yen','JPY','¥',1,1),
		(54,'Pounds','JEP','£',0,0),
		(55,'Tenge','KZT','лв',0,1),
		(56,'Won','KPW','₩',0,0),
		(57,'Won','KRW','₩',0,1),
		(58,'Soms','KGS','лв',0,1),
		(59,'Kips','LAK','₭',0,1),
		(60,'Lati','LVL','Ls',0,0),
		(61,'Pounds','LBP','£',0,1),
		(62,'Dollars','LRD','$',0,1),
		(63,'Switzerland Francs','CHF','CHF',1,1),
		(64,'Litai','LTL','Lt',0,0),
		(65,'Denars','MKD','ден',0,1),
		(66,'Ringgits','MYR','RM',1,1),
		(67,'Rupees','MUR','₨',0,1),
		(68,'Pesos','MXN','$',1,1),
		(69,'Tugriks','MNT','₮',0,1),
		(70,'Meticais','MZN','MT',0,1),
		(71,'Dollars','NAD','$',0,1),
		(72,'Rupees','NPR','₨',0,1),
		(73,'Guilders','ANG','ƒ',0,1),
		(74,'Dollars','NZD','$',1,1),
		(75,'Cordobas','NIO','C$',0,1),
		(76,'Nairas','NGN','₦',0,1),
		(77,'Krone','NOK','kr',1,1),
		(78,'Rials','OMR','﷼',0,0),
		(79,'Rupees','PKR','₨',0,1),
		(80,'Balboa','PAB','B/.',0,1),
		(81,'Guarani','PYG','Gs',0,1),
		(82,'Nuevos Soles','PEN','S/.',0,1),
		(83,'Pesos','PHP','Php',1,1),
		(84,'Zlotych','PLN','zł',1,1),
		(85,'Rials','QAR','﷼',0,1),
		(86,'New Lei','RON','lei',0,1),
		(87,'Rubles','RUB','руб',0,1),
		(88,'Pounds','SHP','£',0,1),
		(89,'Riyals','SAR','﷼',0,1),
		(90,'Dinars','RSD','Дин.',0,1),
		(91,'Rupees','SCR','₨',0,1),
		(92,'Dollars','SGD','$',1,1),
		(93,'Dollars','SBD','$',0,1),
		(94,'Shillings','SOS','S',0,1),
		(95,'Rand','ZAR','R',0,1),
		(96,'Rupees','LKR','₨',0,1),
		(97,'Kronor','SEK','kr',1,1),
		(98,'Dollars','SRD','$',0,1),
		(99,'Pounds','SYP','£',0,0),
		(100,'New Dollars','TWD','NT$',1,1),
		(101,'Baht','THB','฿',1,1),
		(102,'Dollars','TTD','TT$',0,1),
		(103,'Lira','TRY','TL',0,1),
		(104,'Liras','TRL','£',0,0),
		(105,'Dollars','TVD','$',0,0),
		(106,'Hryvnia','UAH','₴',0,1),
		(107,'Pesos','UYU','$"."U',0,1),
		(108,'Sums','UZS','лв',0,1),
		(109,'Bolivares Fuertes','VEF','Bs',0,0),
		(110,'Dong','VND','₫',0,1),
		(111,'Rials','YER','﷼',0,1),
		(112,'Zimbabwe Dollars','ZWD','Z$',0,0);
		";

		$CI->db->query($sql);

	//add column on course table
	$course_fields = array(
	    'course_overview_provider' => array('type' => 'VARCHAR', 'null'  => TRUE, 'constraint' => '255'),
	    'meta_keywords' => array('type' => 'LONGTEXT', 'null'  => TRUE),
	    'meta_description' => array('type' => 'LONGTEXT', 'null'  => TRUE)
	);
	$CI->dbforge->add_column('course', $course_fields);

	//add column on lesson table
	$lesson_fields = array(
	    'lesson_type' => array('type' => 'VARCHAR', 'null'  => TRUE, 'constraint' => '255'),
	    'attachment' => array('type' => 'VARCHAR', 'null'  => TRUE, 'constraint' => '255'),
	    'attachment_type' => array('type' => 'VARCHAR', 'null'  => TRUE, 'constraint' => '255'),
	    'summary' => array('type' => 'LONGTEXT', 'null'  => TRUE)
	);
	$CI->dbforge->add_column('lesson', $lesson_fields);

	// insert data on settings table
	$settings_data = array( 'key' => 'system_currency', 'value' => 'USD' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'paypal_currency', 'value' => 'USD' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'stripe_currency', 'value' => 'USD' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'author', 'value' => 'Creativeitem' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'currency_position', 'value' => 'left' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'website_description', 'value' => 'Nice application' );
	$CI->db->insert('settings', $settings_data);

	$settings_data = array( 'key' => 'website_keywords', 'value' => 'LMS,Learning Management System,Creativeitem' );
	$CI->db->insert('settings', $settings_data);
?>
